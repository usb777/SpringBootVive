package com.springVive.project204;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project204Application {

	public static void main(String[] args) {
		SpringApplication.run(Project204Application.class, args);
	}

}
