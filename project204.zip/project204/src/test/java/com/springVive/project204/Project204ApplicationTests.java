package com.springVive.project204;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project204ApplicationTests {

	@Test
	void contextLoads() {
	}

}
