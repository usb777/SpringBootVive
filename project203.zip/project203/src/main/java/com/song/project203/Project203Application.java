package com.song.project203;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project203Application {

	public static void main(String[] args) {
		SpringApplication.run(Project203Application.class, args);
	}

}
