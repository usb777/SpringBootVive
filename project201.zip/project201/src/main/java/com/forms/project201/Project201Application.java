package com.forms.project201;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project201Application {

	public static void main(String[] args) {
		SpringApplication.run(Project201Application.class, args);
	}

}
